'use strict';


// projects.html
clientControllers.controller('SharesController', ['$scope', '$http', '$state', 'fileUpload', 'loginService', 'UtilityFunctions', 'EncryptionService', '$cookies', '$log', '$timeout', '$sce', 'myconfig', 'SweetAlert', 'UserSessionService', function($scope, $http, $state, fileUpload, loginService, UtilityFunctions, EncryptionService, $cookies, $log, $timeout, $sce, myconfig, SweetAlert, UserSessionService) {
  
    if( loginService.islogged() == false ) {
        $state.go('login');
    }
    
    
    // Set variables.
    $scope.displayName = UserSessionService.getFname();
    $scope.mypic = UserSessionService.getPicture();
    $scope.allFriends = [];
    $scope.allsubscription = [];
    $scope.sharedUsers = [];
    $scope.matrix = "";
    $scope.tTitle    = "";
    $scope.tUserName = "";
    $scope.tPassword = "";
    $scope.tURL = "";
    $scope.tDescription = "";
    
    $scope.teIdno     = "";
    $scope.teTitle    = "";
    $scope.teUserName = "";
    $scope.tePassword = "";
    $scope.teURL = "";
    $scope.teDescription = "";
    
    $scope.tags = "";
    
    //Setup post headers
    var config = { 
        headers : {'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'}
    };

    $scope.rowlimit = 100;
    
    
    $scope.searchquery = "";
    
    //////////////////////////////////////////////////////////////
    // BEGIN: Initialize Modal View
    var modal = new RModal(document.getElementById('modal'), {
        beforeOpen: function(next) {
            console.log('beforeOpen');
            next();
        }
        , afterOpen: function() {
            console.log('opened');
        }

        , beforeClose: function(next) {
            console.log('beforeClose');
            
            /*document.getElementById("btnDeleteAgency").classList.remove("hide");
            document.getElementById("btnSaveAgency").classList.add("hide");
            document.getElementById("btnEditAgency").classList.remove("hide");
            document.getElementById("btnCancelAgency").classList.add("hide");*/
            
            next();
        }
        , afterClose: function() {
            console.log('closed');
        }
    });
    window.modal = modal;
    
    
    var modaledit = new RModal(document.getElementById('modaledit'), {
        beforeOpen: function(next) {
            console.log('beforeOpen');
            next();
        }
        , afterOpen: function() {
            console.log('opened');
        }

        , beforeClose: function(next) {
            console.log('beforeClose');
            
            /*document.getElementById("btnDeleteAgency").classList.remove("hide");
            document.getElementById("btnSaveAgency").classList.add("hide");
            document.getElementById("btnEditAgency").classList.remove("hide");
            document.getElementById("btnCancelAgency").classList.add("hide");*/
            
            next();
        }
        , afterClose: function() {
            console.log('closed');
        }
    });
    window.modaledit = modaledit;
    
    
    
    
    var modalinvitefriends = new RModal(document.getElementById('modalinvitefriends'), {
        beforeOpen: function(next) {
            console.log('beforeOpen');
            next();
        }
        , afterOpen: function() {
            console.log('opened');
        }

        , beforeClose: function(next) {
            console.log('beforeClose');
            
            next();
        }
        , afterClose: function() {
            console.log('closed');
        }
    });
    window.modalinvitefriends = modalinvitefriends;
    
    
    var modalsharewithfriends = new RModal(document.getElementById('modalsharewithfriends'), {
        beforeOpen: function(next) {
            console.log('beforeOpen');
            next();
        }
        , afterOpen: function() {
            console.log('opened');
        }

        , beforeClose: function(next) {
            console.log('beforeClose');
            
            next();
        }
        , afterClose: function() {
            console.log('closed');
        }
    });
    window.modalsharewithfriends = modalsharewithfriends;
    
    // END: Initialize Modal View
    //////////////////////////////////////////////////////////////
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    ////////////////////////////////////////////////////////////////
    // BEGIN: Get All Friends
    $scope.GetAllFriends = function() {
        
        var allFriends = $.param({
            action:'all_friends',
            userid:UserSessionService.getUidentification()
        });
        $http.post('server/application.php',allFriends,config).success(function(data,status,headers,config) {

            if(data.status == "200")
            {
                $scope.allFriends = data.results;
            } else {
                var err = "Error : " + data.results;
                swal(err);
            }

        }).error(function(data,status,headers,config) {
            swal('Error : ' + status);
        });
    };
    // END: Get All Friends
    ////////////////////////////////////////////////////////////////
    
    
    
    ////////////////////////////////////////////////////////////////
    // BEGIN: Get All Subcriptions
    $scope.GetSubscription = function() {
        
        var allSubscription = $.param({
            action:'my_shared_items',
            userid:UserSessionService.getUidentification()
        });
        $http.post('server/application.php',allSubscription,config).success(function(data,status,headers,config) {

            if(data.status == "200")
            {
                $scope.allsubscription = data.results;
                
                //Let's load the results into the martix array by two's
                $scope.matrix = $scope.listToMatrix($scope.allsubscription, 2);
                //angular.forEach($scope.allsubscription, function(item) {    
                //});
                
            } else {
                var err = "Error : " + data.results;
                swal(err);
            }

        }).error(function(data,status,headers,config) {
            swal('Error : ' + status);
        });
    };
    // END: Get All Subcriptions
    ////////////////////////////////////////////////////////////////
    
    
    
    
    
    ////////////////////////////////////////////////////////////////
    // BEGIN: Save Subscription
    $scope.saveSubscription = function() {
        
        var subscription = $.param({
            action:'new_shared_items',
            title:$scope.tTitle,
            userid:UserSessionService.getUidentification(),
            uname:$scope.tUserName,
            pw:$scope.tPassword,
            sharedurl:$scope.tURL,
            description:$scope.tDescription
        });
        $http.post('server/application.php',subscription,config).success(function(data,status,headers,config) {

            if(data.status == "200")
            {
                swal('New subscription added!');
                $scope.GetSubscription();
                $scope.refresh;
                modal.close();
                
            } else {
                var err = "Error : " + data.results;
                swal(err);
            }

        }).error(function(data,status,headers,config) {
            swal('Error : ' + status);
        });
    };
    // END: Save Subscription
    ////////////////////////////////////////////////////////////////
    
    
    
    ////////////////////////////////////////////////////////////////
    // BEGIN: Save Edited Subscription
    $scope.saveEditedSubscription = function() {
        
        var editedsubscription = $.param({
            action:'update_shared_items',
            idno:$scope.teIdno,
            title:$scope.teTitle,
            userid:UserSessionService.getUidentification(),
            uname:$scope.teUserName,
            pw:$scope.tePassword,
            sharedurl:$scope.teURL,
            description:$scope.teDescription
        });
        $http.post('server/application.php',editedsubscription,config).success(function(data,status,headers,config) {

            if(data.status == "200")
            {
                swal('Subscription updated!');
                $scope.GetSubscription();
                $scope.refresh;
                modaledit.close();
                
            } else {
                var err = "Error : " + data.results;
                swal(err);
            }

        }).error(function(data,status,headers,config) {
            swal('Error : ' + status);
        });
    };
    // END: Save Edited Subscription
    ////////////////////////////////////////////////////////////////
    
    
    
    
    ////////////////////////////////////////////////////////////////
    // BEGIN: Send Friend Invite
    $scope.sendFriendInvite = function() {
        
        /*var inviteFriends = $.param({
            action:'send_friend_invite',
            userid:UserSessionService.getUidentification(),
            friends:$scope.tags
        });
        $http.post('server/application.php',inviteFriends,config).success(function(data,status,headers,config) {

            if(data.status == "200")
            {
                swal('Invitation sent!');
                
                modalinvitefriends.close();
                
            } else {
                var err = "Error : " + data.results;
                swal(err);
            }

        }).error(function(data,status,headers,config) {
            swal('Error : ' + status);
        });*/
        
        var errEmail        = document.getElementById("errEmail");
        var errInvalidEmail = document.getElementById("errInvalidEmail");
        var errFname        = document.getElementById("errFname");
        var errLname        = document.getElementById("errLname");
        var errLabel        = document.getElementById("errLabel");
        
        var inviteemail        = document.getElementById("inviteemail");
        var invitefname        = document.getElementById("invitefname");
        var invitelname        = document.getElementById("invitelname");
        
        inviteemail = (inviteemail == null) ? "" : inviteemail;
        invitefname = (invitefname == null) ? "" : invitefname;
        invitelname = (invitelname == null) ? "" : invitelname;
        
        if((inviteemail.value.length>0) && (invitefname.value.length>0) && (invitelname.value.length>0))
        {
            errLabel.style.display = "none"; 
            
            if(inviteemail.value.indexOf('@') < 0) {
                errInvalidEmail.style.display = "block";    
            } else {
                errInvalidEmail.style.display = "none";    
                
                var appPostData = $.param({
                    email:inviteemail.value,
                    fname:invitefname.value,
                    lname:invitelname.value,
                    role:2
                });

                $http.post('server/inviteuser.php',appPostData,config).success(function(data, status, headers, config) {
                    if(data.status == "400")
                    {
                        swal(data.results);
                        
                    } else {
                        if(data.status == "200") {
                            swal("User added to the database. Invitation sent!");
                            inviteemail.value = "";
                            invitefname.value = "";
                            invitelname.value = "";
                            
                            modalinvitefriends.close();
                        }
                    }
                });
            }  
        } else {
            errLabel.style.display = "block";    
        }
        
        
    };
    // END: Send Friend Invite
    ////////////////////////////////////////////////////////////////
    
    
    ////////////////////////////////////////////////////////////////
    // BEGIN: Delete Subscription
    $scope.deleteThis = function(item) {
        
        swal({   
            title: "Delete this entry?",   
            text: "Are you sure you want to delete this entry?",   
            type: "warning",   
            showCancelButton: true,   
            confirmButtonColor: "#DD6B55",   
            confirmButtonText: "Yes",
            cancelButtonText: "Cancel",
            closeOnConfirm: false,
            closeOnCancel: true
        }, function(isConfirm){
            if (isConfirm) {
                
                var delSubscription = $.param({
                    action:'delete_shared_items',
                    userid:UserSessionService.getUidentification(),
                    idno:item.idno
                });
                $http.post('server/application.php',delSubscription,config).success(function(data,status,headers,config) {

                    if(data.status == "200")
                    {
                        swal('Subscription deleted!');
                        
                        //var indexx = $scope.matrix.indexOf(item);
                        //$scope.matrix.splice(indexx, 1);  
                        //$state.reload();
                        $scope.GetSubscription();
                        $scope.refresh;   
                    } else {
                        var err = "Error : " + data.results;
                        swal(err);
                    }

                }).error(function(data,status,headers,config) {
                    swal('Error : ' + status);
                });
                
            } 
        });
        
        
    };
    // END: Delete Subscription
    ////////////////////////////////////////////////////////////////
    
    
    
    
    ////////////////////////////////////////////////////////////////
    // BEGIN: Get Shared Item Users
    $scope.GetSharedItemUsers = function(psharedid) {
        $scope.sharedUsers = [];
        
        var sharedItemUsers = $.param({
            action:'my_shared_items_users',
            userid:UserSessionService.getUidentification()
        });
        
        $http.post('server/application.php',sharedItemUsers,config).success(function(data,status,headers,config) {

            if(data.status == "200")
            {
                $scope.sharedUsers = data.results;
                
            } else {
                $scope.sharedUsers = [];
            }

        }).error(function(data,status,headers,config) {
            swal('Error : ' + status);
        });
        
        //return sharedUsers;
    };
    // END: Get Shared Item Users
    ////////////////////////////////////////////////////////////////
    
    
    
    
    
    
    
    
    
    $scope.loadMore = function() {
        $scope.rowlimit += 100;
        
        if($scope.rowlimit > $scope.projects.length)
            document.getElementById("btnLoadMore").style.display = "none";
        else 
            document.getElementById("btnLoadMore").style.display = "block";
        
        if($scope.showNoPermitOnly) {
            $scope.getAllProjectsNoPermit();
        } else {
            $scope.getAllProjects();
        }
    };
    
    
    $scope.showMore = function() {
        $scope.rowlimit += 100;
        
        if($scope.rowlimit > $scope.projects.length)
            document.getElementById("btnLoadMore").style.display = "none";
        else 
            document.getElementById("btnLoadMore").style.display = "block";
        
        if($scope.showNoPermitOnly) {
            $scope.getAllProjectsNoPermit();
        } else {
            $scope.getAllProjects();
        }
    };
    
    
    ////////////////////////////////////////////////////////////////
    // BEGIN: Shows the Add Subscription Modal box
    $scope.showAddSubscription = function() {
        
        //Let's clear the input text boxes first
        $scope.tTitle       = "";
        $scope.tUserName    = "";
        $scope.tPassword    = "";
        $scope.tURL         = "";
        $scope.tDescription = "";
        
        modal.open();
    };
    // END: Shows the Add Subscription Modal box
    ////////////////////////////////////////////////////////////////
    
    
    
    
    ////////////////////////////////////////////////////////////////
    // BEGIN: Shows the Edit Subscription Modal box
    $scope.showEditSubscription = function(item) {
        
        //Let's clear the input text boxes first
        $scope.teIdno        = item.idno;
        $scope.teTitle       = item.title
        $scope.teTitle       = item.title
        $scope.teUserName    = item.uname;
        $scope.tePassword    = item.pw;
        $scope.teURL         = item.sharedurl;
        $scope.teDescription = item.description;
        
        modaledit.open();
    };
    // END: Shows the Edit Subscription Modal box
    ////////////////////////////////////////////////////////////////
    
    
    
    ////////////////////////////////////////////////////////////////
    // BEGIN: Shows the Invite Friends Modal box
    $scope.showInviteFriends = function(item) {
        
        $scope.tags = ""; 
        
        modalinvitefriends.open();
    };
    // END: Shows the Invite Friends Modal box
    ////////////////////////////////////////////////////////////////
    
    
    
    
    
    
    $scope.doSearch = function() {
        $scope.rowlimit = 0;
        
        if($scope.showNoPermitOnly) {
            $scope.getAllProjectsNoPermit();
        } else {
            $scope.getAllProjects();
        }
        
        $scope.rowlimit = 100;
        
        //Scroll to top of the table
        var tableDiv = document.getElementById("tableDiv");
        tableDiv.scrollTop = 0;
    };
    
    
    
    $scope.listToMatrix = function(list, elementsPerSubArray) {
        var matrix = [], i, k;

        for (i = 0, k = -1; i < list.length; i++) {
            if (i % elementsPerSubArray === 0) {
                k++;
                matrix[k] = [];
            }

            matrix[k].push(list[i]);
        }

        console.log(matrix);
        
        /*var i = 0;
        angular.forEach(matrix, function(item) {
            var it = item[0];
            console.log("Object value: " + it.description);
        });*/
        
        return matrix;
    };
    
    
    $scope.hoverIn = function(){
        this.hoverEdit = true;
    };

    $scope.hoverOut = function(){
        this.hoverEdit = false;
    };
    
    //Let's get the users we shared with.
    $scope.GetSharedItemUsers();
    
    //Get all friends
    $scope.GetAllFriends();
    
    //Get all subscription
    $scope.GetSubscription();
    
    

}]);

