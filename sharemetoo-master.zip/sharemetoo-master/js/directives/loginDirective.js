'use strict';

myApp.directive('loginDirective', function() {
    return {
        templateUrl:'partials/assets/login.tpl.html'
    }
});